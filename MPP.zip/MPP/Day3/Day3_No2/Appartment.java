package Day3_No2;

public class Appartment {
	private int rent;

	 Appartment(int rent) {
		this.rent = rent;
	}

	public int getRent() {
		return rent;
	}
}

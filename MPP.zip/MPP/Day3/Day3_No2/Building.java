package Day3_No2;

import java.util.*;

public class Building {
	private List<Appartment> apprtmentList;
	private int cost;
	private int rent;
	//package level
	Building(int cost, int rent) {
		this.cost=cost;
		this.rent=rent;
		apprtmentList = new ArrayList<Appartment>();
		Appartment app = new Appartment(rent);
		apprtmentList.add(app);
	}

	public void addApartment(int rent) {
		Appartment app = new Appartment(rent);
		apprtmentList.add(app);
	}

	public List<Appartment> getApprtmentList() {
		return apprtmentList;
	}

	public double getCost() {
		return cost;
	}
	
}

package Day3_No3;

public abstract class Properties {

	public Properties() {
		// TODO Auto-generated constructor stub
	}
	public abstract double computeRent();
}

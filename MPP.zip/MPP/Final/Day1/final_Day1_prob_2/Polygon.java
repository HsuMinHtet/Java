package final_Day1_prob_2;

public interface Polygon extends ClosedCurve{

	public double[] getLengths();

	default double computePerimeter() {
		double total = 0.0;
		for (double d : getLengths()) {
			total += d;
		}
		return total;
	}
}

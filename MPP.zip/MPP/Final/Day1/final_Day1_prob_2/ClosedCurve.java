package final_Day1_prob_2;

public interface ClosedCurve {
	public double computePerimeter();
}

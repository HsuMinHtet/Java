package final_Day1_prob_2;

public class EquilateralTraingle implements Polygon {
	private double side;

	public EquilateralTraingle(double side) {
		super();
		this.side = side;
	}

	public double getSide() {
		return side;
	}

	public void setSide(double side) {
		this.side = side;
	}
	@Override
	public double computePerimeter() {
		return 3 * side;
	}
	@Override
	public double[] getLengths() {
		return new double[]{side,side,side};
	}
	
}

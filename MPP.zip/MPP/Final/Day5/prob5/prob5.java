package lesson11.labs.prob5;

import java.util.*;

public class prob5 {

	public static void main(String[] args) {
		List<Integer> numbers = List.of(10, 5, 3, 7, 2, 2);
		List<Character> words = List.of('i', 'b', 'e', 'd', 'a');
		Integer secondSmallest_Int = secondSmallest(numbers);
		Character secondSmallest_word = secondSmallest(words);
		System.out.println("The second smallest element is: " + secondSmallest_Int);
		System.out.println("The second smallest element is: " + secondSmallest_word);
	}

	public static <T extends Comparable<T>> T secondSmallest(List<T> list) {
		if (list.size() < 2) 
			return null;
		T small_1 = list.get(0);
		T small_2 = list.get(1) ;
		if(list.get(0).compareTo(list.get(1))>0) {
			small_1=list.get(1);
			small_2=list.get(0);
		}
		for(T current: list) {
			if (current.compareTo(small_1) < 0) {
				small_2 = small_1;
				small_1 = current;
			} else if (current.compareTo(small_2) < 0) {
				small_2 = current;
			}
		}
		return small_2;
	}

	
}

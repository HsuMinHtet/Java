package final_Day2_prob4;

import java.util.*;

public class Prob4 {

	public static void main(String[] args) {
		List<String> words = List.of("apple", "banana", "chery", "date", "elderberry");
		Prob4 prob4 = new Prob4();
		int result = prob4.countWords(words, 'c', 'd', 5);

		System.out.println("Number of words meeting the criteria(words that have length equal to len, that\n"
				+ "contain the character c, and that do not contain the character d): " + result);

	}

	public int countWords(List<String> words, char c, char d, int len) {

		return (int) words.stream()
				.filter(word -> word.length() == len)
				.filter(word -> word.indexOf(c) > -1)
				.filter(word -> word.indexOf(d) == -1)
				.count();
	}
}

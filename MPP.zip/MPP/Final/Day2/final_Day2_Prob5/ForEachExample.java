package final_Day2_Prob5;

import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;


public class ForEachExample {

	public static void main(String[] args) {
		List<String> list = Arrays.asList("Hello there", "Goodbye", "Back soon", 
				"Away", "On Vacation", "Everywhere you want to be");
		
		//a. Use a lambda expression instead of directly defining a Consumer
		list.forEach(s-> System.out.println(s.toUpperCase()));
		
		//b. Use a method reference in place of your lambda expression in (a)
		Consumer<String> consumer = s-> System.out.println(s.toUpperCase());
		list.forEach(consumer);
	}
}
package final_Day2_prob3;

import java.util.*;
import java.util.function.BiFunction;

public class myBiFunction {

	public static void main(String[] args) {
		class MyBiFunction implements BiFunction<Double, Double, List<Double>> {

			@Override
			public List<Double> apply(Double x, Double y) {
				List<Double> list = new ArrayList<>();
				list.add(Math.pow(x, y));
				list.add(x * y);
				return list;
			}

		}
		MyBiFunction myBi = new MyBiFunction();
		System.out.println(myBi.apply(2.0, 3.0));

	}

}

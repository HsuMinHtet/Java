package final_Day2_prob6;

import java.util.function.Supplier;

public class Prob6_exercise8_3 {

	public static void main(String[] args) {
		Supplier<Double> f=() -> Math.random();

	}

}

package lesson9.labs.prob9;


import java.util.stream.Stream;

public class Square {

	public static void main(String[] args) {

		printSquares(4);
		/*
		for(int i=1;i<4;i++) {
			int num=i*i;
			System.out.println(calculateNextSquare(num));
		}
		*/
	}
	
	public static void printSquares(int num) {
		Stream.iterate(1, Square::calculateNextSquare).limit(num).forEach(n -> System.out.print(n + (n == 16 ? "" : ", ")));
	}
	
	public static int calculateNextSquare(int previousSquare) {
		int square=0;
		square= (int)Math.sqrt(previousSquare) +1 ;
		return (int) Math.pow(square, 2);
		
	}
}

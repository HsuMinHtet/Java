package lesson9.labs.prob10a;

import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Or {

	public static void main(String[] args) {
		List<Simple> list = Arrays.asList(new Simple(false), new Simple(false), new Simple(true));
		Stream<String> stringStream= Stream.of("Bill","Thomas","Mary");
		Stream<Integer> myIntStream= Stream.of(1,2,3,4,5);
		//a
		System.out.println(someSimpleIsTrue_stream(list));
		//b
		stringPrint(stringStream);
		//c
		minmaxInteger(myIntStream);
	}
	
	public static boolean someSimpleIsTrue(List<Simple> list) {
		boolean accum = false;			
		for(Simple s: list) {
			accum = accum || s.flag;
		}
		return accum;
	}
	public static boolean someSimpleIsTrue_stream(List<Simple> list) {
		return list.stream().map(s->s.flag).reduce(false,(x,y)->x||y);
	}
	
	public static void stringPrint(Stream<String> stringStream) {
		List<String> list= stringStream.collect(Collectors.toList());
		System.out.println(list);
	}
	public static void minmaxInteger(Stream<Integer> myIntStream) {
		IntSummaryStatistics summary= myIntStream.collect(Collectors.summarizingInt(x->x));
		System.out.println("Min: "+ summary.getMin());
		System.out.println("Max: "+ summary.getMax());
	}
}

package lesson9.labs.prob11b;

import java.util.function.Function;
import java.util.function.Predicate;

public class LambdaLibrary {
	public static final Predicate<lesson9.labs.prob11b.Employee> checkSalary= e ->e.getSalary()>100000;
	public static final Predicate<Employee> checkLastName= e->{
		char ch= e.getLastName().charAt(0);
		return ch >='N' && ch<='Z';
	};
	public static final Function<Employee, String> fullName= e->{
		String fullName= e.getFirstName()+" "+e.getLastName();
		return fullName;
	};
}

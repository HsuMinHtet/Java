package Day2_No2_1;

public class Grade {

	String grade;

	public Grade(String grade) {
		this.grade = grade;
	}

	public String getGrade() {
		return grade;
	}

	@Override
	public String toString() {
		return grade;
	}

}

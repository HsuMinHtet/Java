package Day2_No2_1;

public class Student {
	private String name;
	private GradeReport gradeReport;

	// for 1 multiplicities(create object of gradeReport in constructor)
	public Student(String name) {
		this.name = name;
		this.gradeReport = new GradeReport(this);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public GradeReport getGrade() {
		return gradeReport;
	}

	@Override
	public String toString() {
		return name;
	}

}

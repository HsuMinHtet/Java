package Day2_No2_1;

import java.util.*;

public class GradeReport {
	private Student owner;
	private ArrayList<Grade> grade = new ArrayList<Grade>();

	// package level
	GradeReport(Student owner) {
		this.owner = owner;
	}

	public void addGrade(Grade g) {
		grade.add(g);
	}

	public List<Grade> getGades() {
		return grade;
	}

	public Student getOwner() {
		return owner;
	}
}

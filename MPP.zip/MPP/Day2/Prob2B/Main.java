package Day2_No2_2;

public class Main {

	public static void main(String[] args) {
		OrderOrderListFactory factory= new OrderOrderListFactory();
		Order order =factory.createOrderOrderListFactory(10);
		order.getOrderLine().addOrder(1);
		order.getOrderLine().addOrder(2);
		order.getOrderLine().addOrder(3);
		System.out.println(order.getOrderNum());
		System.out.println(order.getOrderLine().getOrderList().toString());
	}

}

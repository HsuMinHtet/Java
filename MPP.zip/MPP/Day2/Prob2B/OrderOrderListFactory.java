package Day2_No2_2;

public class OrderOrderListFactory {

	public static Order createOrderOrderListFactory(int num) {
		if(num==0)
			throw new IllegalArgumentException("Order should not be null.");
		Order ord= new Order(num);
		OrderLine ordLine= new OrderLine();
		ordLine.setOrder(ord);
		ord.setOrderLine(ordLine);
		return ord;
	}
	
}

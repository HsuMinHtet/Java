package Day4_5;

public class CheckingAccount extends Account{
	private double balance;
	private double monthlyFee;
	private String acctId;
	
	public CheckingAccount(String acctId, double fee, double startBalance) {
		this.balance=startBalance;
		this.monthlyFee=fee;
		this.acctId=acctId;
	}

	@Override
	public String getAccountID() {
		return this.acctId;
	}

	@Override
	public double getBalance() {
		return balance;
	}

	@Override
	public double computeUpdatedBalance() {
		double updateBalance=0.0;
		if(balance!=0)
			updateBalance=this.balance-this.monthlyFee;
		return updateBalance;
	}

}

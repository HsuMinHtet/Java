package Day4;

import java.time.LocalDate;
import java.util.*;

public class Commissioned extends Employee {
	private double commission;
	private double baseSalary;
	private List<Order> list;

	public Commissioned(String empId, double commission, double salary, List<Order> list) {
		super(empId);
		this.commission = commission;
		this.baseSalary = salary;
		this.list = list;
	}

	@Override
	public double calcGrossPay(int month, int year) {
		double orderAmount = 0.0;
		double commissionTotal=0.0;
		int m = LocalDate.now().getDayOfMonth();
		int y = 0;
		for (Order o : list) {
			m = o.getOrderDate().getMonthValue();
			y = o.getOrderDate().getYear();
			if (month == 1 && m == 12 && y == year - 1) {
				orderAmount += o.getOrderAmount();
			} else if (month - 1 == m && y == year) {
				orderAmount += o.getOrderAmount();
			}
		}
		commissionTotal=orderAmount*(commission);
		return baseSalary+commissionTotal  ;
	}

}

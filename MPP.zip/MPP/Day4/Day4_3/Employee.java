package Day4;

import java.time.LocalDate;

public abstract class Employee {
	private String empId;

	public Employee(String empId) {
		this.empId = empId;

	}

	// copy from question
	public void print(int month, int year) {
		System.out.println("Employee Id:"+empId);
		Paycheck paycheck = calcCompensation(month, year);
		paycheck.print();
	}

	// calculate here base on day month
	public Paycheck calcCompensation(int month, int year) {
		Paycheck paycheck = new Paycheck(calcGrossPay(month, year));
		paycheck.getNetPay();
		
		return paycheck;
	}

	public abstract double calcGrossPay(int month, int year);
}

package Day4;

public final class Paycheck {
	private static final double fica = 0.23;
	private static final double state = 0.05;
	private static final double local = 0.01;
	private static final double medical = 0.03;
	private static final double socialSecurity = 0.075;
	private final double grossPay;

	public Paycheck(double grossPay) {

		this.grossPay = grossPay;
	}

	public void print() {
		String s = "Paystub: \n Gross Pay: " + grossPay + "\n Fica: " + fica + "\n State:" + state + "\n Local: "
				+ local + "\n Medicare: " + medical + "\n Social Security :" + socialSecurity + "\n NET PAY : "
				+ getNetPay();
		System.out.println(s);
	}

	public double getNetPay() {
		double netPay = 0.0;
		netPay = grossPay - ((grossPay*fica) + (grossPay*state)+ (grossPay*local)+(grossPay*socialSecurity)+ (grossPay*medical));
		return netPay;
	}
}

/**
 * 
 */
/**
 * 
 */
module lab5_prob1 {
	requires java.desktop;
}
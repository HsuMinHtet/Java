package rulesets;

import java.awt.Component;

import gui.*;

/**
 * Rules: 1. All fields must be nonempty 2. Isbn must be numeric and consist of
 * either 10 or 13 characters 3. If Isbn has length 10, the first digit must be
 * 0 or 1 4. If Isbn has length 13, the first 3 digits must be either 978 or 979
 * 5. Price must be a floating point number with two decimal places 6. Price
 * must be a number greater than 0.49.
 *
 */
public class BookRuleSet implements RuleSet {
	private BookWindow bookW;

	@Override
	public void applyRules(Component ob) throws RuleException {
		bookW = (BookWindow) ob;
		nonemptyRule();
		IsbnNumericRule();
		PriceRule();

	}

	private void nonemptyRule() throws RuleException {
		if (bookW.getIsbnValue().trim().isEmpty() || bookW.getTitle().trim().isEmpty()
				|| bookW.getPriceValue().trim().isEmpty()) {
			throw new RuleException("All fields must be non-empty!");
		}
	}

	private void IsbnNumericRule() throws RuleException {
		String val = bookW.getIsbnValue().trim();
		try {
			Long.parseLong(val) ;

			// val is numeric
		} catch (NumberFormatException e) {
			throw new RuleException("ISBN must be numeric");
		}

		if (val.length() == 10) {
			System.out.println(val.charAt(0));
			System.out.println(val.charAt(0) != '0' && val.charAt(0) != '1');
			if (val.charAt(0) != '0' && val.charAt(0) != '1') {
				throw new RuleException("ISBN is 10 digits , it must have started 0 or 1");
			}
		}
		if (val.length() == 13) {
			String str = val.substring(0,3);
			System.out.print(str);
			if (str.equals("978") && str.equals("979") ){
				throw new RuleException("ISBN is 13 digits, it must have started 978 or 979");
			}
			if (!str.equals("978")) {
				 if( !str.equals("979")){
				throw new RuleException("ISBN is 13 digits, it must have started 978 or 979");
				 }
			}
		}
		if (val.length() != 10 && val.length() != 13)
			throw new RuleException("ISBN must have 10 or 13 digits");

	}

	private void PriceRule() throws RuleException {
		String val = bookW.getPriceValue().trim();
		try {
			double d = Double.parseDouble(val);
			if (d < 0.49) {
				throw new RuleException("Price value must be float greater than 0.49");
			}

			// val is numeric
		} catch (NumberFormatException e) {
			throw new RuleException("Price value must be float with 2 decimal");
		}

	}

}

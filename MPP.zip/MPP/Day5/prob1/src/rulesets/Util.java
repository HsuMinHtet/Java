package rulesets;

public final class Util {

	public static void validateTwoDecimalPlaces(String value) throws RuleException {
		String priceVal = value.substring(value.length() - 3, value.length());

		if (priceVal.charAt(0) != '.') {

			throw new RuleException("Price must have two decimal numbers");
		}

	}

	public static void checkNumLargerThan(String value, double numToCompare) throws RuleException {
		double valueDouble;

		try {
			valueDouble = Double.parseDouble(value);
		} catch (NumberFormatException e) {
			throw new RuleException("Value must be numeric");
		}

		if (valueDouble <= numToCompare)
			throw new RuleException("Value must be greater than " + numToCompare);
	}

}
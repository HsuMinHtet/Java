package lesson5.labs.prob4;

import java.time.LocalDate;

public class CustOrderFactory {
	public static Customer createCustomer(String cusName) {
		//Customer cus = Customer.createCustomer(cusName);
		return Customer.createCustomer(cusName);
	}
	public static Order createOrder(Customer cus,LocalDate localdate) {
		return Order.newOrder(cus,localdate);
	}

}

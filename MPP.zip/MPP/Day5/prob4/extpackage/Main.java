package lesson5.labs.prob4.extpackage;

import java.time.LocalDate;

import lesson5.labs.prob4.*;

public class Main {

	public static void main(String[] args) {
		Customer cus = CustOrderFactory.createCustomer("Sue");
		Order ord = CustOrderFactory.createOrder(cus, LocalDate.of(2021, 12, 1));

		ord.addItem("Apple");
		ord.addItem("Orange");

		System.out.println(cus.getName());
		System.out.println(cus.getOrders());

		Customer cus1 = CustOrderFactory.createCustomer("Bob");
		Order ord1 = CustOrderFactory.createOrder(cus1, LocalDate.now());
		ord1.addItem("Apple");
		ord1.addItem("Orange");
		Order ord2 = CustOrderFactory.createOrder(cus1, LocalDate.of(2023, 10, 7));
		ord2.addItem("Coke");
		ord2.addItem("Beer");

		System.out.println(cus1.getName() + cus1.getOrders());

	}

}

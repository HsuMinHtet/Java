package lesson5.labs.prob4;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Main {

	public static void main(String[] args) {
		Customer cus = CustOrderFactory.createCustomer("Bob");
		Order ord = CustOrderFactory.createOrder(cus, LocalDate.now());
		ord.addItem("Apple");
		ord.addItem("Orange");
		Order ord1 = CustOrderFactory.createOrder(cus, LocalDate.of(2023, 10, 7));
		ord1.addItem("Coke");
		ord1.addItem("Beer");
		
		System.out.println(cus.getName() + cus.getOrders());
	}

}

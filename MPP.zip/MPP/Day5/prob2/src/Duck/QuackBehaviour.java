package Duck;

public interface QuackBehaviour {
	void quack();
}

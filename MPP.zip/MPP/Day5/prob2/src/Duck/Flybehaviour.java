package Duck;

public interface Flybehaviour {
	void fly();
}

package Duck;

public abstract class Duck implements Flybehaviour, QuackBehaviour {
	@Override
	public void quack() {
		System.out.println("  quacking");
	}

	@Override
	public void fly() {
		System.out.println("  fly with wings");

	}

	public abstract void display();

	public void swim() {
		System.out.println("  swimming");
	}

}

package Duck;

public class MallardDuck extends Duck {
	@Override
	public void display() {
		System.out.println("  display");
	}
	
}

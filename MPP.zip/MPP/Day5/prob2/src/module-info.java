/**
 * 
 */
/**
 * 
 */
module Lab5_prob2 {
}